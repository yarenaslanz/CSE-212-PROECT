import javax.swing.JFrame;

public class Level1Main {

	public static void main(String[] args) {
		JFrame obj = new JFrame("LEVEL 1");
		obj.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		level1 level1 = new level1();
		
		obj.setBounds(10, 10, 700, 600);
		obj.setResizable(false); 		
		obj.add(level1);
		obj.setVisible(true);
		
	}

}
