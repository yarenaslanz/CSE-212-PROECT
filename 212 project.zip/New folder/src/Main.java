
import java.awt.event.*;
import javax.swing.*;
import java.awt.*;


public class Main extends JFrame {
	
	
	public static void main(String[] args) {
		
		JFrame jframe = new JFrame("Arkanoid Game");
		jframe.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		JPanel mainpanel = new JPanel();
		mainpanel.setLayout(new FlowLayout(FlowLayout.CENTER, 100, 100));
		JButton btn1,btn2,btn3,btn4,btn5,btn6;
		btn1 = new JButton("NEW GAME");
		btn2 = new JButton("OPTIONS");
		btn3 = new JButton("SCORES");
		btn4 = new JButton("HELP");
		btn5 = new JButton("ABOUT");
		btn6 = new JButton("EXIT");
		
		JPanel panel1 = new JPanel();
		panel1.add(btn1);
		panel1.add(btn2);
		panel1.add(btn3);
		panel1.add(btn4);
		panel1.add(btn5);
		panel1.add(btn6);
		
		
		ActionListener actionListener = new ActionListener() {
		      public void actionPerformed(ActionEvent e) {
		      	JOptionPane.showMessageDialog (null, "Yaren Aslan\n 20200702065\n yaren.aslan@std.yeditepe.edu.tr","ABOUT", JOptionPane.INFORMATION_MESSAGE);

		      }
		};
		
		ActionListener actionListener2 = new ActionListener() {
		      public void actionPerformed(ActionEvent e) {
		      	JOptionPane.showMessageDialog (null, "Break all bricks with ball by moving paddle left and right. Use left-right keys on keyboard.","HELP", JOptionPane.INFORMATION_MESSAGE);

		      }
		};
		
		btn6.addActionListener(e -> {
	         jframe.dispose();
	      });
		
		btn5.addActionListener(actionListener);
		btn4.addActionListener(actionListener2);

		panel1.setLayout(new GridLayout(6,1,20,30));
		mainpanel.add(panel1);
		jframe.add(mainpanel);
		jframe.setSize(300, 500);
		jframe.setVisible( true );
		
	}
}
	

